README

Title: 
Massachusetts Beach Grain Size and Slope Data

Authors: 
Jonathan D. Woodruff*, Nicholas Venti*, Stephen Mabee+, Alycia DiTroia*, Douglas Beach*
Affiliations: 
*Department of Geosciences, University of Massachusetts, Amherst, MA 01003, USA
+Massachusetts Geological Survey, Amherst, MA 01003, USA
Description

This data repository contains grain size and beach face slope data from approximately 100 paired summer and winter transects collected along 18 separate beaches in southern New England. The study is focused to beaches of Massachusetts, which represents a particularly unique section of the Northeastern US coast in that it: 1) lies at the interface between New England’s paraglacial lowlands and Mid-Atlantic Coastal Plain, 2) spans both micro- and meso- tidal regimes, 3) encompasses a wide range of seasonally varying wave conditions, and 4) contains a diverse array of geomorphic and grain size characteristics. Between 2 and 10 intertidal transects were conducted for each of the sites depending on the length of the beach and accessibility. Transect positions were chosen at representative locations along the beach and equally spaced when possible. At each transect at least three separate samples were collected at near 1) high-tide, 2) mid-tide and 3) low-tide. When possible, additional samples were collected along berm crest, storm berms and dune. To assess seasonal variations in grain size distribution and slope, all transects along beaches were sampled and surveyed twice, once at the end of the summer and then revisited again at the end of the winter season.  Surface sediments from the top 15-30 cm were collected from sites primarily composed of sand and pebbles (i.e. < 64 mm), and brought back to the University of Massachusetts in Amherst, MA for analysis. Exclusively sand samples were collected in 1-liter (1-quart) bags, predominantly sand samples were collected in 4-liter (1-gallon) bags and mixed sand and pebble samples in 19 -liter (5 gallon) buckets. Areas comprised primarily of cobbles and boulder (> 64 mm) were measured in the field using a gravelometer and standard pebble count technique. Sediment samples were washed and dried thoroughly to remove salt and debris (sticks, seaweed, etc.). Each sample was weighed and sub-divided into fractions greater and less than 4 mm. Distributions for grains greater than 4 mm were obtained via standard sieving techniques. Grain size distributions for sample fractions < 4 mm were measured on a CAMSIZER digital particle size analyzer capable of measuring particles between 30 μm and 4 mm. The elevation of each sampling location as well as inter-tidal beach slope for each transect was obtained using a using a Real Time Kinematic (RTK) GPS survey system or a total station survey system tied to local benchmarks. 

The primary dataset within this repository is presented in the accompanying excel spreadsheet entitled: 
Massachusetts_Beaches_GrainSize_Slope.xlsx

From left to right the table includes:
1) Beach Name
2) Season (summer or winter)
3) Transect Letter
4) Beach Location (e.g. low tide, mid tide, high tide, berm crest, storm high tide or dune)
5) Sampling Date
6) Latitude for sample position (in degrees)
7) Longitude for sample position (in degrees)
8) Elevation (vertical datum=NAVD 88, units=meters)
9) Beach Face Slope (calculated using the vertical and horizontal differences between high and low tide locations) 
10-61) Cumulative percent finer than grain size provided in 2nd row (where grain size is given in mm and in increments of 0.25 phi).

Seasonal significant wave heights and mean tidal ranges for each beach site are provided in the supporting table entitled:
Massachusetts_Beaches_WaveHeight_Tides.xlsx

From left to right columns in this table include:
1) Beach Name
2) Latitude for Beach (in degrees)
3) Longitude for Beach (in degrees)
4) Season (winter or summer)
5-7) Year, Month and Day of Seasonal Sampling
8) Average Significant Wave Height (Hsig) over the preceeding 30-days (in meters)
9) The maximum 12-hr average Hsig in 30-days prior to sampling (in meters)
10) Mean Tidal Range at site (in meters)

Off-shore wave conditions were independently reconstructed for each beach based on publicly available results from the United States Geological Survey (USGS) Coupled Ocean-Atmospheric-Wave-Sediment Transport (COAWST) model (Warner and others, 2010), and using the nearest deep-water grid cell to each respective beach location.

Reference:

Warner JC, Armstrong B, He R, Zambon JB. Development of a coupled ocean–atmosphere–wave–sediment transport (COAWST) modeling system. Ocean modelling. 2010 Jan 1;35(3):230-44.
